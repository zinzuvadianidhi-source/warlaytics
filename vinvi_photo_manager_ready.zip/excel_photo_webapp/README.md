# 📸 Product Photo Manager

A Flask web app to manage product photos stored in an Excel file (`database.xlsx`).

## Features
- Login with admin/user roles
- Upload product photos (PNG, JPG, JPEG, WEBP)
- Tag photos by type: Front, Back, Left, Right, Top, Bottom, Tag
- Search photos by product name, type, or uploader
- Edit and delete entries (delete is admin-only)
- All data stored in `database.xlsx` — no database needed

---

## 🚀 Run Locally

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Start the app
python app.py
```

Visit: **http://localhost:5000**

### Default Logins
| Username | Password | Role  |
|----------|----------|-------|
| admin    | admin123 | Admin |
| user     | user123  | User  |

> ⚠️ **Change these credentials** in `app.py` before going live!

---

## ☁️ Deploy to Render (Free)

1. Push this folder to a GitHub repo
2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect your GitHub repo
4. Render auto-detects `render.yaml` — click **Deploy**

The `render.yaml` and `Procfile` are already configured.

---

## 🔐 Before Going Live

Edit `app.py` and update these:

```python
app.secret_key = "your-random-secret-here"   # Change this!

USERS = {
    "yourname": {"password": "strongpassword", "role": "admin"},
}
```

---

## 📁 File Structure

```
excel_photo_webapp/
├── app.py              # Main Flask app
├── requirements.txt    # Python dependencies
├── Procfile            # For Render/Heroku
├── render.yaml         # Render deployment config
├── database.xlsx       # Auto-created on first run
├── static/
│   ├── style.css
│   └── uploads/        # Uploaded photos go here
└── templates/
    ├── base.html
    ├── login.html
    ├── dashboard.html
    ├── add.html
    └── edit.html
```
